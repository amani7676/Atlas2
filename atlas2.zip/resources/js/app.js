import './bootstrap';
import { cuteAlert, cuteToast } from 'cute-alert';

window.cuteAlert = cuteAlert;
window.cuteToast = cuteToast;




