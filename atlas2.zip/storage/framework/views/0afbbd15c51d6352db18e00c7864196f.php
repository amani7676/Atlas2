<div class="wrapper" wire:id="<?php echo e($this->getId()); ?>">

    <div class="content">
        <div class="container-fluid px-4 mt-4">

            
            <div class="row">
                
                <div class="col-lg-7">
                    <?php echo $__env->make('livewire.pages.home.partials.expirs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                
                <div class="col-lg-5">
                    <?php echo $__env->make('livewire.pages.home.partials.reservations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('livewire.pages.home.partials.nightly', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            
            <div class="row mt-4">
                
                <div class="col-lg-7">
                    <?php echo $__env->make('livewire.pages.home.partials.exists', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                
                <div class="col-lg-5">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pages.home.componets.empty-beds', ['allReportService' => $allReportService,'beds' => $beds]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1629479574-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>

            
            <div class="row mt-4">
                
                <div class="col-12 col-sm-12 col-md-6 col-lg-4 mb-3 mb-md-0">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pages.home.componets.documetns', ['allReportService' => $allReportService]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1629479574-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                
                <div class="col-12 col-sm-12 col-md-6 col-lg-4 mb-3 mb-md-0">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pages.home.componets.forms', ['allReportService' => $allReportService]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1629479574-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                
                <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                    <?php echo $__env->make('livewire.pages.home.partials.payments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

        </div>
    </div>

        <?php
        $__scriptKey = '1629479574-0';
        ob_start();
    ?>
    <script>
        // !!! گوش دادن به رویداد 'show-toast'
        window.addEventListener('show-toast', (event) => {
            const params = event.detail[0];

            // !!! فراخوانی cuteToast به جای cuteAlert
            if (typeof window.cuteToast === 'function') {
                cuteToast({
                    type: params.type,
                    title: params.title,
                    description: params.description,
                    timer: params.timer // timer در Toast ضروری است
                });
            } else {
                console.error('cuteToast function is not available on window object.');
            }
        });
        
        // Dispatch delete-note event to Home component only
        let homeComponentId = null;
        
        document.addEventListener('livewire:initialized', () => {
            // Get Home component ID
            const wrapper = document.querySelector('.wrapper[wire\\:id]');
            if (wrapper) {
                homeComponentId = wrapper.getAttribute('wire:id');
            }
        });
        
        window.addEventListener('delete-note-event', (event) => {
            const noteId = event.detail.noteId;
            if (homeComponentId) {
                const homeComponent = Livewire.find(homeComponentId);
                if (homeComponent) {
                    homeComponent.call('handleDeleteNote', noteId);
                }
            } else {
                // Fallback: try to find component
                const wrapper = document.querySelector('.wrapper[wire\\:id]');
                if (wrapper) {
                    const id = wrapper.getAttribute('wire:id');
                    const component = Livewire.find(id);
                    if (component) {
                        component.call('handleDeleteNote', noteId);
                    }
                }
            }
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\laragon\www\Atlas2\resources\views/livewire/pages/home/home.blade.php ENDPATH**/ ?>