<div>
    <div class="container-fluid mt-3" style="width: 90%">


        
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h2 class="text-primary">
                        <i class="fas fa-bed me-2"></i>
                        رزروها
                    </h2>
                    <button wire:click="showCreateForm" class="btn btn-success">
                        <i class="fas fa-plus me-2"></i>
                        رزرو جدید
                    </button>
                </div>
            </div>
        </div>

        
        <?php if($showForm): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-<?php echo e($editingId ? 'edit' : 'plus'); ?> me-2"></i>
                            <?php echo e($editingId ? 'ویرایش رزرو' : 'رزرو جدید'); ?>

                        </h5>
                        <button wire:click="hideForm" class="btn btn-sm btn-outline-light">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <form wire:submit.prevent="save">
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required">نام و نام خانوادگی</label>
                                    <input type="text"
                                           wire:model="full_name"
                                           class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="نام کامل را وارد کنید">
                                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required">شماره تماس <span class="text-danger">*</span></label>
                                    <input type="text"
                                           wire:model.live="phone"
                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="0912-345-6789"
                                           maxlength="13"
                                           pattern="09\d{2}-\d{3}-\d{4}"
                                           required>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="form-text text-muted">فرمت: 0912-345-6789 (11 رقم با 09 شروع شود)</small>
                                </div>
                            </div>


                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label required">اولویت</label>
                                    <select wire:model="priority"
                                            class="form-select <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="low">کم</option>
                                        <option value="medium">متوسط</option>
                                        <option value="high">بالا</option>
                                    </select>
                                    <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">یادداشت</label>
                                    <textarea wire:model="note"
                                              class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                              rows="3"
                                              placeholder="یادداشت اختیاری..."></textarea>
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>
                                <?php echo e($editingId ? 'ویرایش' : 'ذخیره'); ?>

                            </button>
                            <button type="button" wire:click="hideForm" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i>
                                انصراف
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        



























        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-list me-2"></i>
                    لیست رزروها (<?php echo e(count($reserves)); ?> مورد)
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if(count($reserves) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                            <tr>
                                <th style="width: 15%">نام و نام خانوادگی</th>
                                <th style="width: 15%">شماره تماس</th>
                                <th style="width: 5%">اولویت</th>
                                <th style="width: 35%">یادداشت</th>

                                <th style="width: 15%">تاریخ ایجاد</th>
                                <th width="150">عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $reserves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($reserve->full_name); ?></strong>
                                    </td>
                                    <td>
                                        <span class="text-muted"><?php echo e($reserve->phone); ?></span>
                                    </td>

                                    <td>
                                        <span class="<?php echo e($this->getPriorityClass($reserve->priority)); ?>">
                                            <?php echo e($this->getPriorityLabel($reserve->priority)); ?>

                                        </span>
                                    </td>
                                    <td >
                                        <?php if($reserve->note): ?>
                                            <span class="text-muted"
                                                  title="<?php echo e($reserve->note); ?>"
                                                  data-bs-toggle="tooltip">
                                                <?php echo e($reserve->note); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted fst-italic">بدون یادداشت</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?php echo e($reserve->created_at_jalali); ?>

                                        </small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button wire:click="edit(<?php echo e($reserve->id); ?>)"
                                                    class="btn btn-outline-primary " style="margin-left: 10px;"
                                                    title="ویرایش">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button wire:click="delete(<?php echo e($reserve->id); ?>)"
                                                    class="btn btn-outline-danger"
                                                    title="حذف"
                                                    onclick="return confirm('آیا از حذف این رزرو اطمینان دارید؟')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-bed fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">هیچ رزروی یافت نشد</h5>
                        <p class="text-muted">برای شروع، یک رزرو جدید ایجاد کنید.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php $__env->startPush('styles'); ?>
        <style>

            .required::after {
                content: " *";
                color: red;
            }

            .table th {
                border-top: none;
                font-weight: 600;
                color: #495057;
            }

            .btn-group-sm > .btn {
                padding: 0.25rem 0.5rem;
                font-size: 0.875rem;
            }

            .card {
                border: none;
                box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            }

            .card-header {
                background-color: #f8f9fa;
                border-bottom: 1px solid #e9ecef;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                // Initialize tooltips
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });

                // فرمت‌دهی خودکار شماره تلفن
                const phoneInput = document.querySelector('input[wire\\:model="phone"]');
                if (phoneInput) {
                    phoneInput.addEventListener('input', function (event) {
                        let value = event.target.value.replace(/\D/g, ''); // حذف کاراکترهای غیر عددی
                        
                        // اگر با 0 شروع نشود، اضافه کردن 0
                        if (value.length > 0 && !value.startsWith('0')) {
                            value = '0' + value;
                        }
                        
                        // محدود کردن به 11 رقم
                        value = value.substring(0, 11);
                        
                        // فرمت کردن شماره تلفن
                        let formattedValue = '';
                        if (value.length > 0) {
                            formattedValue = value.substring(0, 4);
                        }
                        if (value.length > 4) {
                            formattedValue += '-' + value.substring(4, 7);
                        }
                        if (value.length > 7) {
                            formattedValue += '-' + value.substring(7, 11);
                        }
                        
                        event.target.value = formattedValue;
                        
                        // به‌روزرسانی Livewire
                        if (window.Livewire) {
                            const component = event.target.closest('[wire\\:id]');
                            if (component) {
                                const wireId = component.getAttribute('wire:id');
                                const livewireComponent = window.Livewire.find(wireId);
                                if (livewireComponent) {
                                    livewireComponent.set('phone', formattedValue);
                                }
                            }
                        }
                    });

                    // اعتبارسنجی هنگام blur
                    phoneInput.addEventListener('blur', function (event) {
                        let value = event.target.value.replace(/\D/g, '');
                        
                        if (value.length > 0 && value.length !== 11) {
                            event.target.classList.add('is-invalid');
                        } else if (value.length === 11 && value.startsWith('09')) {
                            event.target.classList.remove('is-invalid');
                        }
                    });
                }
            });

            // گوش دادن به رویداد 'show-toast'
            window.addEventListener('show-toast', (event) => {
                const params = event.detail[0];

                if (typeof window.cuteToast === 'function') {
                    cuteToast({
                        type: params.type,
                        title: params.title,
                        description: params.description,
                        timer: params.timer
                    });
                } else {
                    console.error('cuteToast function is not available on window object.');
                }
            });

        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\laragon\www\Atlas2\resources\views\livewire\pages\reservations\reservations.blade.php ENDPATH**/ ?>