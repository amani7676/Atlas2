<div>
    <div class="container-fluid px-4 mt-4">
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i>
                    فیلترها
                </h5>
                <?php if($startDate || $endDate || $unitId || $roomId || $name || $phone || $nationalCode): ?>
                    <span class="badge bg-light text-dark">
                        <i class="fas fa-check-circle me-1"></i>
                        فیلتر فعال
                    </span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <!-- فیلتر تاریخ شروع -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">تاریخ شروع:</label>
                        <input type="text" 
                               id="start_date_picker" 
                               wire:model="startDate"
                               class="form-control" 
                               placeholder="روی این فیلد کلیک کنید"
                               style="cursor: pointer; background-color: #fff;">
                    </div>

                    <!-- فیلتر تاریخ پایان -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">تاریخ پایان:</label>
                        <input type="text" 
                               id="end_date_picker" 
                               wire:model="endDate"
                               class="form-control" 
                               placeholder="روی این فیلد کلیک کنید"
                               style="cursor: pointer; background-color: #fff;">
                    </div>

                    <!-- فیلتر واحد -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">
                            <i class="fas fa-building me-1"></i>
                            واحد:
                        </label>
                        <select wire:model.live="unitId" class="form-select">
                            <option value="">همه واحدها</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unit['id']); ?>"><?php echo e($unit['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- فیلتر اتاق -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">
                            <i class="fas fa-door-open me-1"></i>
                            اتاق:
                        </label>
                        <select wire:model.live="roomId" class="form-select" <?php echo e($unitId ? '' : 'disabled'); ?>>
                            <option value="">همه اتاق‌ها</option>
                            <?php if($unitId): ?>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($room['id']); ?>"><?php echo e($room['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="">ابتدا واحد را انتخاب کنید</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <!-- فیلتر نام -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">
                            <i class="fas fa-user me-1"></i>
                            نام:
                        </label>
                        <input type="text" 
                               wire:model.live.debounce.300ms="name"
                               class="form-control" 
                               placeholder="جستجو بر اساس نام...">
                    </div>

                    <!-- فیلتر تلفن -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">
                            <i class="fas fa-phone me-1"></i>
                            شماره تلفن:
                        </label>
                        <input type="text" 
                               wire:model.live.debounce.300ms="phone"
                               class="form-control" 
                               placeholder="جستجو بر اساس تلفن...">
                    </div>

                    <!-- فیلتر کد ملی -->
                    <div class="col-md-6 col-lg-3">
                        <label class="form-label">
                            <i class="fas fa-id-card me-1"></i>
                            کد ملی:
                        </label>
                        <input type="text" 
                               wire:model.live.debounce.300ms="nationalCode"
                               class="form-control" 
                               placeholder="جستجو بر اساس کد ملی...">
                    </div>

                    <!-- دکمه‌های عملیات -->
                    <div class="col-md-12 d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <button wire:click="resetFilters" class="btn btn-secondary">
                                <i class="fas fa-redo me-2"></i>
                                پاک کردن همه فیلترها
                            </button>
                        </div>
                        <div class="text-muted small">
                            <i class="fas fa-info-circle me-1"></i>
                            تعداد نتایج: <strong><?php echo e(count($residents)); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- جدول اقامتگران خروجی -->
        <div class="card">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    اقامتگران خروجی
                    <span class="badge bg-light text-dark ms-2"><?php echo e(count($residents)); ?></span>
                </h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>نام</th>
                                <th>کد ملی</th>
                                <th>تلفن</th>
                                <th>واحد</th>
                                <th>اتاق</th>
                                <th>تخت</th>
                                <th>تاریخ شروع</th>
                                <th>تاریخ پایان</th>
                                <th>تاریخ حذف</th>
                                <th>توضیحات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $residents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($data['resident']['full_name'] ?? '-'); ?></td>
                                    <td><?php echo e($data['resident']['document'] ?? '-'); ?></td>
                                    <td><?php echo e($data['resident']['phone'] ?? '-'); ?></td>
                                    <td><?php echo e($data['unit']['name'] ?? '-'); ?></td>
                                    <td><?php echo e($data['room']['name'] ?? '-'); ?></td>
                                    <td>
                                        <span class="bed-info-container">
                                            <span class="bed-number-badge">
                                                <i class="fas fa-bed"></i>
                                                <?php echo e($data['bed']['name'] ?? '-'); ?>

                                            </span>
                                        </span>
                                    </td>
                                    <td><?php echo e($data['contract']['start_date'] ?? '-'); ?></td>
                                    <td><?php echo e($data['contract']['end_date'] ?? '-'); ?></td>
                                    <td>
                                        <?php if(isset($data['contract']['deleted_at']) && $data['contract']['deleted_at']): ?>
                                            <span class="badge bg-danger"><?php echo e($data['contract']['deleted_at']); ?></span>
                                        <?php elseif(isset($data['resident']['deleted_at']) && $data['resident']['deleted_at']): ?>
                                            <span class="badge bg-danger"><?php echo e($data['resident']['deleted_at']); ?></span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $data['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $noteRepository = app(\App\Repositories\NoteRepository::class);
                                                $noteText = $note['note'];
                                                if ($note['type'] === 'end_date' && preg_match('/(\d{4})\/(\d{1,2})\/(\d{1,2})/', $noteText, $matches)) {
                                                    $noteText = $matches[2] . '/' . $matches[3];
                                                } else {
                                                    $noteText = $noteRepository->formatNoteForDisplay($note);
                                                }
                                                $badgeStyle = $noteRepository->getNoteBadgeStyle($note['type']);
                                            ?>
                                            <span class="badge rounded-pill" style="<?php echo e($badgeStyle); ?> margin: 2px; display: inline-block; font-size: 0.85rem;">
                                                <?php echo e($noteText); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center py-4">
                                        <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                        <p class="text-muted">هیچ اقامتگر خروجی یافت نشد</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

        <?php
        $__scriptKey = '2605071040-0';
        ob_start();
    ?>
    <script>
        (function() {
            function initDatePickers() {
                // Wait for jalaliDatepicker to be loaded
                if (typeof jalaliDatepicker === 'undefined') {
                    console.warn('Jalali Datepicker not loaded yet, retrying...');
                    setTimeout(initDatePickers, 200);
                    return;
                }

                // Initialize start date picker
                const startInput = document.getElementById('start_date_picker');
                if (startInput) {
                    // Remove existing instance if any
                    if (startInput._jalaliDatepicker) {
                        jalaliDatepicker.stopWatch('#start_date_picker');
                    }

                    jalaliDatepicker.startWatch({
                        date: true,
                        time: false,
                        autoShow: true,
                        autoHide: true,
                        hideAfterChange: true,
                        persianDigits: true,
                        separatorChars: {
                            date: '/',
                            between: ' ',
                            time: ':'
                        },
                        selector: '#start_date_picker'
                    });

                    startInput.addEventListener('change', function() {
                        const selectedDate = this.value;
                        if (selectedDate) {
                            $wire.set('startDate', selectedDate);
                        }
                    });
                }

                // Initialize end date picker
                const endInput = document.getElementById('end_date_picker');
                if (endInput) {
                    // Remove existing instance if any
                    if (endInput._jalaliDatepicker) {
                        jalaliDatepicker.stopWatch('#end_date_picker');
                    }

                    jalaliDatepicker.startWatch({
                        date: true,
                        time: false,
                        autoShow: true,
                        autoHide: true,
                        hideAfterChange: true,
                        persianDigits: true,
                        separatorChars: {
                            date: '/',
                            between: ' ',
                            time: ':'
                        },
                        selector: '#end_date_picker'
                    });

                    endInput.addEventListener('change', function() {
                        const selectedDate = this.value;
                        if (selectedDate) {
                            $wire.set('endDate', selectedDate);
                        }
                    });
                }
            }

            // Initialize when DOM is ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function() {
                    setTimeout(initDatePickers, 500);
                });
            } else {
                setTimeout(initDatePickers, 500);
            }

            // Re-initialize after Livewire updates
            document.addEventListener('livewire:init', function() {
                setTimeout(initDatePickers, 500);
            });

            document.addEventListener('livewire:update', function() {
                setTimeout(initDatePickers, 500);
            });

            // Also try after window load
            window.addEventListener('load', function() {
                setTimeout(initDatePickers, 500);
            });
        })();
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>

<?php /**PATH C:\laragon\www\Atlas2\resources\views\livewire\pages\reports\exited-residents.blade.php ENDPATH**/ ?>