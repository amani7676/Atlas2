<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="span-exit">خروجی‌ها</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr class="tr-exit">
                        <th>#</th>
                        <th>اتاق</th>
                        <th>تخت / کل</th>
                        <th>نام</th>
                        <th>تلفن</th>
                        <th>سررسید</th>
                        <th>مانده</th>
                        <th>توضیحات</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $counter = 0;
                    ?>

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->allReportService->getAllResidentsWithDetails('contract.day_since_payment', 'asc'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($data['contract']['state'] === 'leaving'): ?>
                            <?php $counter++; ?>
                            <tr>
                                <td class="text-info"><?php echo e($counter); ?></td>
                                <td><?php echo e($data['room']['name']); ?></td>
                                <td><?php echo e($data['bed']['name']); ?> <i class="fa-solid fa-water"></i>
                                    <?php echo e($data['room']['bed_count']); ?></td>
                                <td><?php echo e($data['resident']['full_name']); ?></td>
                                <td><?php echo e($data['resident']['phone']); ?></td>
                                <td><?php echo e($data['contract']['payment_date']); ?></td>
                                <td>
                                    <?php echo $statusService->getStatusBadge($data['contract']['day_since_payment']); ?>


                                </td>
                                <td style="max-width: 250px;">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge rounded-pill text-bg-info p-2"><?php echo e($note['note']); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <a href="<?php echo e(route('table_list')); ?>#<?php echo e($data['room']['name']); ?>" target="_blank"
                                       class="text-primary action-btn">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\atlas2\resources\views/livewire/pages/home/partials/exists.blade.php ENDPATH**/ ?>