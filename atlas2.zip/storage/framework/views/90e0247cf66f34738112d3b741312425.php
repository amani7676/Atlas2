<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>مدارک</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>اتاق</th>
                        <th>نام</th>
                        <th>تلفن</th>
                        <th>سررسید</th>
                        <th>توضیح</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $counter = 0;
                    ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->allReportService->getAllResidentsWithDetails(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if(!$data['resident']['document']): ?>
                            <?php
                                $counter++;
                            ?>
                            <tr>
                                <td class="text-info"><?php echo e($counter); ?></td>
                                <td><?php echo e($data['room']['name']); ?></td>
                                <td><?php echo e($data['resident']['full_name']); ?></td>
                                <td><?php echo e($data['resident']['phone']); ?></td>
                                <td><?php echo e($data['contract']['payment_date']); ?></td>
                                <td style="max-width: 250px;">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!--[if BLOCK]><![endif]--><?php if($note['type'] === 'payment'): ?>
                                            <span class="badge rounded-pill text-bg-info p-2"><?php echo e($note['note']); ?></span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <a href="#" wire:click.prevent="giveDocumented(<?php echo e($data['resident']['id']); ?>)"
                                        class="text-success action-btn">
                                        <i class="fas fa-check-circle"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\atlas2\resources\views/livewire/pages/home/componets/documetns.blade.php ENDPATH**/ ?>