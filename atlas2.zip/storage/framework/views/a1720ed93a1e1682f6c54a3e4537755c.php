<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>بدهی‌ها</span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>#</th>
                    <th>اتاق</th>
                    <th>نام</th>
                    <th>تلفن</th>
                    <th>سررسید</th>
                    <th>توضیح</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>

                <?php $counter = 1; ?>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->allReportService->getAllResidentsWithDetails(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if($data['notes']->contains(fn($note) => in_array($note['type'], ['payment']))): ?>
                        <tr>
                            <td class="text-info"><?php echo e($counter++); ?></td>
                            <td><?php echo e($data['room']['name']); ?></td>
                            <td><?php echo e($data['resident']['full_name']); ?></td>
                            <td><?php echo e($data['resident']['phone']); ?></td>
                            <td><?php echo e($data['contract']['payment_date']); ?></td>
                            <td style="max-width: 250px;">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data['notes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge rounded-pill text-dark p-2">
                        <?php echo e($this->noteRepository->formatNoteForDisplay($note)); ?>

                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td>
                                <a href="<?php echo e(route('table_list')); ?>#<?php echo e($data['room']['name']); ?>" target="_blank"
                                   class="text-primary action-btn">
                                    <i class="fas fa-external-link-alt"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\atlas2\resources\views/livewire/pages/home/partials/payments.blade.php ENDPATH**/ ?>