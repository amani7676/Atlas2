<nav class="navbar navbar-expand-lg modern-navbar">
    <div class="container">
        <!-- دکمه موبایل -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarContent">
            <!-- منوی اصلی -->
            <ul class="nav-menu ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("home")); ?>">
                        <i class="fas fa-home"></i>
                        صفحه اصلی
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('table_list')); ?>">
                        <i class="fas fa-list"></i>
                        لیست اقامتگران
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("Bed_statistic")); ?>">
                        <i class="fas fa-chart-bar"></i>
                        آمار تخت ها
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("reservations")); ?>">
                        <i class="fas fa-calendar-plus"></i>
                        رزرو کردن
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-file-alt"></i>
                        گزارش‌ها
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route("report.list_current_resident")); ?>">
                                <i class="fas fa-users"></i>
                                اقای عنایتی
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route("report.chart_one")); ?>">
                                <i class="fas fa-users"></i>
                                Chart One
                            </a>
                        </li>
                        <li><a class="dropdown-item" href="#">
                                <i class="fas fa-sign-out-alt"></i>
                                اقامتگران خروجی
                            </a></li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("coolers")); ?>">
                        <i class="fa-solid fa-fan"></i>
                        کولرها
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('keys')); ?>">
                        <i class="fa-solid fa-key"></i>
                        کلیدها
                    </a>
                </li>
            </ul>

            <!-- بخش جستجو با Livewire -->
            <div style="position: relative;">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.live-search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2833595032-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\atlas2\resources\views/components/layouts/menu.blade.php ENDPATH**/ ?>